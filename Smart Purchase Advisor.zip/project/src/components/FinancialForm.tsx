import React from 'react';
import { DollarSign, Home, PiggyBank, CreditCard, Target } from 'lucide-react';
import { FinancialProfile } from '../types';
import { useSettings } from '../contexts/SettingsContext';

interface Props {
  initialData: FinancialProfile;
  onSubmit: (data: FinancialProfile) => void;
}

const FinancialForm: React.FC<Props> = ({ initialData, onSubmit }) => {
  const [formData, setFormData] = React.useState(initialData);
  const { settings } = useSettings();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: parseFloat(value) || 0
    }));
  };

  const fields = [
    { name: 'monthlyIncome', label: 'Monthly Income After Taxes', icon: DollarSign },
    { name: 'essentialExpenses', label: 'Essential Monthly Expenses', icon: Home },
    { name: 'currentSavings', label: 'Current Savings', icon: PiggyBank },
    { name: 'currentDebt', label: 'Current Debt', icon: CreditCard },
    { name: 'monthlyGoal', label: 'Monthly Savings Goal', icon: Target }
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 transition-colors duration-200">
      <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-6">
        Your Financial Profile
      </h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        {fields.map(({ name, label, icon: Icon }) => (
          <div key={name} className="relative">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {label}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Icon className="h-5 w-5 text-gray-400 dark:text-gray-500" />
              </div>
              <input
                type="number"
                name={name}
                value={formData[name as keyof FinancialProfile]}
                onChange={handleChange}
                className="block w-full pl-10 pr-12 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                placeholder="0.00"
                min="0"
                step="0.01"
                required
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <span className="text-gray-500 dark:text-gray-400">{settings.currency.code}</span>
              </div>
            </div>
          </div>
        ))}
        
        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center space-x-2"
        >
          <span>Continue</span>
          <DollarSign className="w-5 h-5" />
        </button>
      </form>
    </div>
  );
};

export default FinancialForm;