import React, { useState, useEffect } from 'react';
import { ArrowLeft, RefreshCcw, ThumbsUp, ThumbsDown, DollarSign, PiggyBank, CreditCard, TrendingUp } from 'lucide-react';
import { FinancialProfile, Purchase } from '../types';
import { calculateRecommendation } from '../utils';
import { useSettings } from '../contexts/SettingsContext';

interface Props {
  financialProfile: FinancialProfile;
  purchase: Purchase;
  onReset: () => void;
  onBack: () => void;
}

const LoadingScreen = () => (
  <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 transition-colors duration-200">
    <div className="flex flex-col items-center justify-center space-y-4">
      <div className="relative w-20 h-20">
        <div className="absolute inset-0 rounded-full border-4 border-blue-100 dark:border-blue-900"></div>
        <div className="absolute inset-0 rounded-full border-4 border-blue-500 border-t-transparent animate-spin"></div>
        <div className="absolute inset-2 rounded-full border-4 border-blue-200 dark:border-blue-800 border-b-transparent animate-spin-reverse"></div>
      </div>
      <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">Analyzing Purchase</h2>
      <p className="text-gray-600 dark:text-gray-400 text-center max-w-sm">
        Crunching the numbers to provide you with a detailed financial recommendation...
      </p>
    </div>
  </div>
);

const Analysis: React.FC<Props> = ({ financialProfile, purchase, onReset, onBack }) => {
  const { settings } = useSettings();
  const [loading, setLoading] = useState(true);
  const [analysis, setAnalysis] = useState<ReturnType<typeof calculateRecommendation> | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      const result = calculateRecommendation(financialProfile, purchase);
      setAnalysis(result);
      setLoading(false);
    }, 1500); // Show loading for 1.5 seconds

    return () => clearTimeout(timer);
  }, [financialProfile, purchase]);

  if (loading || !analysis) {
    return <LoadingScreen />;
  }

  const {
    disposableIncome,
    debtRatio,
    savingsImpact,
    recommendationScore,
    recommendation
  } = analysis;

  const metrics = [
    {
      label: 'Monthly Disposable Income',
      value: `${settings.currency.symbol}${disposableIncome.toFixed(2)}`,
      icon: DollarSign,
      color: disposableIncome > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
    },
    {
      label: 'Debt-to-Income Ratio',
      value: `${(debtRatio * 100).toFixed(1)}%`,
      icon: CreditCard,
      color: debtRatio < 0.36 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
    },
    {
      label: 'Impact on Savings Goal',
      value: `${(savingsImpact * 100).toFixed(1)}%`,
      icon: PiggyBank,
      color: savingsImpact > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
    },
    {
      label: 'Purchase Recommendation',
      value: `${(recommendationScore * 100).toFixed(0)}%`,
      icon: TrendingUp,
      color: recommendationScore > 0.7 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
    }
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 transition-colors duration-200">
      <div className="text-center mb-8">
        <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full ${
          recommendation === 'buy' ? 'bg-green-100 dark:bg-green-900' : 'bg-red-100 dark:bg-red-900'
        } mb-4`}>
          {recommendation === 'buy' ? (
            <ThumbsUp className="w-10 h-10 text-green-600 dark:text-green-400" />
          ) : (
            <ThumbsDown className="w-10 h-10 text-red-600 dark:text-red-400" />
          )}
        </div>
        <h2 className={`text-3xl font-bold ${
          recommendation === 'buy' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
        }`}>
          {recommendation === 'buy' ? 'Go ahead!' : 'Not Recommended'}
        </h2>
        <p className="text-gray-600 dark:text-gray-300 mt-2">
          {recommendation === 'buy'
            ? 'This purchase appears to be within your financial means.'
            : 'This purchase might strain your finances.'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {metrics.map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div className="flex items-center space-x-3 mb-2">
              <Icon className={`w-5 h-5 ${color}`} />
              <span className="text-gray-600 dark:text-gray-300 text-sm">{label}</span>
            </div>
            <div className={`text-2xl font-bold ${color}`}>
              {value}
            </div>
          </div>
        ))}
      </div>

      <div className="flex space-x-4">
        <button
          onClick={onBack}
          className="flex-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 py-3 px-6 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors duration-200 flex items-center justify-center space-x-2"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>
        <button
          onClick={onReset}
          className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center space-x-2"
        >
          <RefreshCcw className="w-5 h-5" />
          <span>Start Over</span>
        </button>
      </div>
    </div>
  );
};

export default Analysis;