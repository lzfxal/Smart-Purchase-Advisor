import React from 'react';
import { Sun, Moon, Settings } from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';

const Header: React.FC = () => {
  const { settings, setCurrency, toggleTheme } = useSettings();

  return (
    <header className="text-center mb-12">
      <div className="flex justify-end mb-4 space-x-4">
        <select
          value={settings.currency.code}
          onChange={(e) => setCurrency(e.target.value)}
          className="px-3 py-1 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100"
        >
          <option value="USD">USD ($)</option>
          <option value="EUR">EUR (€)</option>
          <option value="GBP">GBP (£)</option>
          <option value="JPY">JPY (¥)</option>
          <option value="AUD">AUD (A$)</option>
        </select>
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-gray-100"
        >
          {settings.isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
      </div>
      <h1 className="text-4xl font-bold text-indigo-900 dark:text-indigo-100 mb-4">
        Smart Purchase Advisor
      </h1>
      <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
        Make informed financial decisions by analyzing your purchase against your current financial situation
      </p>
    </header>
  );
};

export default Header;