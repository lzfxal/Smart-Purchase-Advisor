import React, { createContext, useContext, useState, useEffect } from 'react';

interface Settings {
  currency: {
    code: string;
    symbol: string;
  };
  isDarkMode: boolean;
}

interface SettingsContextType {
  settings: Settings;
  setCurrency: (code: string) => void;
  toggleTheme: () => void;
}

const currencies = {
  USD: { code: 'USD', symbol: '$' },
  EUR: { code: 'EUR', symbol: '€' },
  GBP: { code: 'GBP', symbol: '£' },
  JPY: { code: 'JPY', symbol: '¥' },
  AUD: { code: 'AUD', symbol: 'A$' },
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<Settings>({
    currency: currencies.USD,
    isDarkMode: window.matchMedia('(prefers-color-scheme: dark)').matches,
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (settings.isDarkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings.isDarkMode]);

  const setCurrency = (code: string) => {
    setSettings(prev => ({
      ...prev,
      currency: currencies[code as keyof typeof currencies],
    }));
  };

  const toggleTheme = () => {
    setSettings(prev => ({
      ...prev,
      isDarkMode: !prev.isDarkMode,
    }));
  };

  return (
    <SettingsContext.Provider value={{ settings, setCurrency, toggleTheme }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}