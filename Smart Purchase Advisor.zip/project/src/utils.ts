import { FinancialProfile, Purchase, AnalysisResult } from './types';

export function calculateRecommendation(
  profile: FinancialProfile,
  purchase: Purchase
): AnalysisResult {
  // Calculate disposable income
  const disposableIncome = profile.monthlyIncome - profile.essentialExpenses;

  // Calculate debt-to-income ratio
  const debtRatio = profile.currentDebt / (profile.monthlyIncome * 12);

  // Calculate impact on savings goal
  const monthlyPurchaseImpact = purchase.type === 'recurring' 
    ? purchase.price 
    : purchase.price / 12;
  const savingsImpact = (profile.monthlyGoal - monthlyPurchaseImpact) / profile.monthlyGoal;

  // Calculate recommendation score (0-1)
  let recommendationScore = 0;

  // Factor 1: Disposable income coverage (30%)
  const disposableIncomeScore = Math.min(
    disposableIncome / (purchase.type === 'recurring' ? purchase.price : purchase.price / 6),
    1
  ) * 0.3;

  // Factor 2: Debt ratio (25%)
  const debtScore = (1 - Math.min(debtRatio / 0.36, 1)) * 0.25;

  // Factor 3: Savings impact (25%)
  const savingsScore = Math.max(savingsImpact, 0) * 0.25;

  // Factor 4: Purchase necessity (20%)
  const necessityScore = purchase.category === 'necessity' ? 0.2 : 0.1;

  recommendationScore = disposableIncomeScore + debtScore + savingsScore + necessityScore;

  return {
    disposableIncome,
    debtRatio,
    savingsImpact,
    recommendationScore,
    recommendation: recommendationScore >= 0.7 ? 'buy' : 'dont-buy'
  };
}