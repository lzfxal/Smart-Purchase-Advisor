export interface FinancialProfile {
  monthlyIncome: number;
  essentialExpenses: number;
  currentSavings: number;
  currentDebt: number;
  monthlyGoal: number;
}

export interface Purchase {
  price: number;
  type: 'one-time' | 'recurring';
  category: 'necessity' | 'luxury';
}

export interface AnalysisResult {
  disposableIncome: number;
  debtRatio: number;
  savingsImpact: number;
  recommendationScore: number;
  recommendation: 'buy' | 'dont-buy';
}