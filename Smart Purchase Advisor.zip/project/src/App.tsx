import React from 'react';
import { useState } from 'react';
import { Calculator, Wallet, ShoppingBag, ArrowRight } from 'lucide-react';
import { FinancialProfile, Purchase } from './types';
import FinancialForm from './components/FinancialForm';
import PurchaseForm from './components/PurchaseForm';
import Analysis from './components/Analysis';
import Header from './components/Header';
import { SettingsProvider } from './contexts/SettingsContext';

function App() {
  const [step, setStep] = useState(1);
  const [financialProfile, setFinancialProfile] = useState<FinancialProfile>({
    monthlyIncome: 0,
    essentialExpenses: 0,
    currentSavings: 0,
    currentDebt: 0,
    monthlyGoal: 0
  });
  const [purchase, setPurchase] = useState<Purchase>({
    price: 0,
    type: 'one-time',
    category: 'necessity'
  });

  const handleFinancialSubmit = (data: FinancialProfile) => {
    setFinancialProfile(data);
    setStep(2);
  };

  const handlePurchaseSubmit = (data: Purchase) => {
    setPurchase(data);
    setStep(3);
  };

  const resetApp = () => {
    setStep(1);
    setFinancialProfile({
      monthlyIncome: 0,
      essentialExpenses: 0,
      currentSavings: 0,
      currentDebt: 0,
      monthlyGoal: 0
    });
    setPurchase({
      price: 0,
      type: 'one-time',
      category: 'necessity'
    });
  };

  return (
    <SettingsProvider>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-indigo-950 transition-colors duration-200 relative">
        <div className="geometric-background">
          <div className="shape shape-1"></div>
          <div className="shape shape-2"></div>
        </div>
        
        <div className="container mx-auto px-4 py-8 relative z-10">
          <Header />

          <div className="flex justify-center mb-12">
            <div className="flex items-center space-x-4">
              {[
                { icon: Wallet, text: 'Financial Profile' },
                { icon: ShoppingBag, text: 'Purchase Details' },
                { icon: Calculator, text: 'Analysis' }
              ].map((item, index) => (
                <React.Fragment key={index}>
                  <div className={`flex items-center space-x-2 ${
                    step > index + 1 ? 'text-green-600 dark:text-green-400' :
                    step === index + 1 ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400 dark:text-gray-500'
                  }`}>
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-sm ${
                      step > index + 1 ? 'bg-green-100/80 dark:bg-green-900/80' :
                      step === index + 1 ? 'bg-blue-100/80 dark:bg-blue-900/80' : 'bg-gray-100/80 dark:bg-gray-800/80'
                    }`}>
                      <item.icon className="w-5 h-5" />
                    </div>
                    <span className="hidden sm:inline font-medium">{item.text}</span>
                  </div>
                  {index < 2 && (
                    <ArrowRight className={`w-4 h-4 ${
                      step > index + 1 ? 'text-green-600 dark:text-green-400' : 'text-gray-300 dark:text-gray-600'
                    }`} />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          <div className="max-w-3xl mx-auto">
            {step === 1 && (
              <FinancialForm 
                initialData={financialProfile}
                onSubmit={handleFinancialSubmit}
              />
            )}
            {step === 2 && (
              <PurchaseForm
                initialData={purchase}
                onSubmit={handlePurchaseSubmit}
                onBack={() => setStep(1)}
              />
            )}
            {step === 3 && (
              <Analysis
                financialProfile={financialProfile}
                purchase={purchase}
                onReset={resetApp}
                onBack={() => setStep(2)}
              />
            )}
          </div>
        </div>
      </div>
    </SettingsProvider>
  );
}

export default App;